function calculatePenalty(prisonMonths) {
  if (prisonMonths < 6) return 0.05;
  if (prisonMonths < 24) return 0.15;
  if (prisonMonths < 60) return 0.25;
  return 0.40;
}
